import json
import boto3
import time 
from datetime import datetime

def lambda_handler(event, context):
    # TODO implement
    string = "The following file was used  " + event["file_key"]
    encoded_string = string.encode("utf-8")

    bucket_name = "silen-lambda-test"
    file_name = "AT_Result_"+ str(datetime.now()) + "_.txt"
    s3_path =  file_name

    s3 = boto3.resource("s3")
    s3.Bucket(bucket_name).put_object(Key=s3_path, Body=encoded_string)
    print(event)
    print("Sucessfully invoked from MAP")
    return {
        
        'statusCode': 200,
        'body': json.dumps('Sucessfully invoked from MAP' + str(event))
    }
